using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class attack_1 : MonoBehaviour
{
   [SerializeField] enemy_attack_1 enemy_Attack_1;
    

}
