// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;

// public class Enemy_attack_1 : MonoBehaviour
// {
//     Rigidbody2D rb;
//     SpriteRenderer spriteRenderer;
//     Animator animator;
//     enemy_movement enemy_Movement=new enemy_movement();
//     public float attack_range = 0.25f;

//     void Start()
//     {
//         rb = GetComponent<Rigidbody2D>();
//         spriteRenderer = GetComponent<SpriteRenderer>();
//         animator = GetComponent<Animator>();
//     }

//     public void check_attack_range(float currentDistance)
//     {
//         if (currentDistance <= attack_range)
//         {
//             animator.SetBool("Is_attack", true);
//             enemy_attack_1();
//         }
//     }
//     void enemy_attack_1()
//     {
//         if (animator.GetBool("Is_attack") == false && enemy_Movement.calcDistance() <= attack_range)
//         {

//         }
//     }

// }
