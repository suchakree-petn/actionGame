using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetActiveWhenEnd : MonoBehaviour
{
    void SetActive_False()
    {
        this.gameObject.SetActive(false);
    }
}
